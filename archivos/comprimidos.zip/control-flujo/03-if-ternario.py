edad = 18

# if edad > 17:
#     mensaje = "Es mayor de edad"
# else:
#     mensaje = "Es menor de edad"

mensaje = "Es mayor" if edad > 17 else "Es menor"  # if ternario

print(mensaje)
