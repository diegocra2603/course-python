class Animal:
    def comer(self):
        print("comiendo")

class Perro(Animal):
    def pasear(self):
        print("paseando")

class Chachito(Perro):
    
    def programar(self):
        print("programar")


chancito = Chachito()

