try:
    n1 = int(input("Ingresa el primer numero: "))
except:
    print("Ocurrion un erro :( ")
