nombre = "Diego"
apellido = "Cruz"
nombre_completo = nombre + " " + apellido
nombre_completo_f = f"{nombre[0]} {apellido} {2 + 5}"
print(nombre_completo)
print(nombre_completo_f)
