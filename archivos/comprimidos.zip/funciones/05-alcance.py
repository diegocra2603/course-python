saludo = "Hola Global"

def saludar():
    saludo = "Hola mundo"
    
def saludoChanchito():
    saludo = "Hola Chancito"
    print(saludo)
    
saludar()
print(saludo)
saludar()