edad = int(input("Ingrese su edad: "))

if edad >= 65:
    print("Tiene un super descuento")
elif edad >= 55:
    print("Tiene un descuento")
elif edad > 17:
    print("Puede ver la película")
else:
    print("No puede ver la película")

print("Fin del programa")
