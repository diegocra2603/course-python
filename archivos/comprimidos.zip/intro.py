"""INTRODUCCION A PYTHON"""

print("Hola Mundo")
print("El weta " * 4)
