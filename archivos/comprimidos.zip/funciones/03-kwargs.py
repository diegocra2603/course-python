def get_product(**datos):
    print(datos['id'], datos['name'])


get_product(id="id", name="IPhone", desc="Esto es un Iphone")
