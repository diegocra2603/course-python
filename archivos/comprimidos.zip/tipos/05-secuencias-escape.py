curso = "Ultimate \\\"Python\" \n Holaa"
# Esto es un comentario \
print(curso)
