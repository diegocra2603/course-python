"""Strings en Python"""

nombre_curso = "Ultimate Python"
descripcion_curso = """
Ulitimate Python contempla todos los detalles 
que necesitas aprender para encontrar un trabajo como programador
"""
print(nombre_curso, descripcion_curso)
print(len(descripcion_curso))
print(nombre_curso[0])
print(nombre_curso[0:8])
print(nombre_curso[9:])
print(nombre_curso[:8])
print(nombre_curso[:])
print(nombre_curso[0:8:2])
