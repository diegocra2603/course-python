def guardar():
    print("guardando")

def pagar_impuestos():
    print("pagar Impuesto")