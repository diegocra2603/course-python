"""Variables en Python"""

nombre_curso = "Ultimate Python"
nombre1 = "Diego Jose Cruz"
NOMBRE_CURSO = "ULTIMATE PYTHON"

print(nombre_curso, nombre1, NOMBRE_CURSO)

alumnos = 5000
puntaje = 9.9
publicado = True

print(type(nombre_curso))
print(type(alumnos))
print(type(puntaje))
print(type(publicado))
