def suma(a , b):
    return a + b

print(suma(1, 5) + 90)