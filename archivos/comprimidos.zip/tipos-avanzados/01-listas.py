numeros = [1, 2, 3, 4]
print(numeros)
letras = ["a", "b", "c"]
palabras = ["chancito", "feliz"]
palabras_felices = ["chancito", "feliz", "Felipe", "Alumno"]
print(palabras)
print(palabras_felices)
boleans = [True, False, True]
print(boleans)
matriz = [
    [
        0, 1
    ],
    [
        1, 0
    ]
]

print(matriz)

ceros = [0,1] * 10

print(ceros)

alfanumerico = numeros + letras

print(alfanumerico)

rango = list(range(1,11))

print(rango)

chars = list("Hola mundo")

print(chars)
