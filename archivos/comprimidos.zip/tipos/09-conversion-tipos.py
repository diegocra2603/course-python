x = input("")

# int(x) #int() convierte a entero
# str(x) #str() convierte a cadena
# float(x) #float() convierte a flotante
# bool(x) #bool() convierte a booleano

print(bool(""))
print(bool("0"))
print(bool(None))
print(bool(" "))
print(bool(0))
