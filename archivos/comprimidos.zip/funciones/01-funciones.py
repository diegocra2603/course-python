def hola(nombre, apellido = "feliz"):
    print("Hola Mundo")
    print(f"Bienvenido {nombre} {apellido}")


hola('Diego', 'Cruz') 
hola('Chancito') 


hola(apellido="Cruz", nombre="Diego Jose")