mensaje = "Hola mundo"
print(type(mensaje))

# Clase: Es el plano de contruccion
# Objeto: Es una instancia de una clase

# Clases: El palno de construccion de una casa
# Objeto: la casa contruida

# Clase: Humano
# Objeto: Diego, Juan, Maria, Sofia