def init(db, api, **_):
    print("Soy modulo dos: {db}, {api}")