mascotas = ["Pelusa", "Pulga", "Felipe", "Chanchito feliz"]

# primero, segundo = [1,2] tuplas
for indice, mascota in enumerate(mascotas):
    print(indice, mascota)