numero_entero = 2  # Entero (int)
numero_decimal = 2.5  # Decimal (float)
numero_imaginario = 2 + 2j  # Imaginario (complex)

# numero_entero = numero_entero + 2
numero_entero += 5
numero_entero *= 2
numero_entero /= 2
numero_entero -= 2
numero_entero %= 2

print("Numero", numero_entero)

# Operaciones
print(1 + 3)  # Suma
print(7 - 3)  # Resta
print(4 * 2)  # Multiplicación
print(18 / 4)  # División flotante
print(18 // 4)  # División entera
print(8 % 3)  # Módulo
print(2 ** 3)  # Potencia
