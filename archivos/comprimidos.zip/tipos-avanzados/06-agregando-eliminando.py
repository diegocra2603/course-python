mascotas = ["Pelusa","Wolfgang","Pulga","Felipe","Chanchito feliz","Wolfgang"]

mascotas.insert(1, "Melvin")
mascotas.append("Chancito Triste")

mascotas.remove("Pulga")
mascotas.pop(1)
del mascotas[0]
mascotas.clear()
print(mascotas)
