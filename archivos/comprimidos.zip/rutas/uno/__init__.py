def init(graphql, **_):
    print("Soy modulo uno: {graphql}")