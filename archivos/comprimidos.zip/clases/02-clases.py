class Perro:
        def habla(self):
                print("Gua!")


mi_perro = Perro()
mi_perro.habla()
print(isinstance(mi_perro, str))